package com.example.masterfood;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        Button cadastro = findViewById(R.id.cadastro);
        Button ok_Login = findViewById(R.id.okLogin);
        TextView erro_Login = findViewById(R.id.esqueceuSenha);
        EditText email = findViewById(R.id.email);
        EditText senha = findViewById(R.id.senha);

        cadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), CadastroActivity.class);
                startActivity(intent);
            }
        });


        ok_Login.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onClick(View v) {
                ControleBanco crud = new ControleBanco(getBaseContext());
                Cursor cursor = crud.carregaDadosUsuario();

                String[] nomeCampos = new String[] {MasterFoodContract.Usuario.COLUNA_EMAIL, MasterFoodContract.Usuario.COLUNA_SENHA};

                if(email.toString().isEmpty() || senha.toString().isEmpty()){
                    erro_Login.setText("Preencha todos os campos!");
                    return;
                }

                else if (nomeCampos != null){
                    Intent intent = new Intent(getApplicationContext(), CardapioActivity.class);
                    startActivity(intent);
                }

                else {
                    erro_Login.setText("Senha ou usuário incorretos!");
                    return;
                }
            }
        });

        //Intent intent = getIntent();
    }
}
