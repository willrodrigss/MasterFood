package com.example.masterfood;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class CadastroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);


        Button login = findViewById(R.id.login);
        Button ok_cadastro = findViewById(R.id.okCadastro);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                startActivity(intent);
            }
        });


        ok_cadastro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ControleBanco crud = new ControleBanco(getBaseContext());
                EditText email = findViewById(R.id.cadastroemail);
                EditText telefone = findViewById((R.id.cadastrotelefone));
                EditText senha = findViewById(R.id.senha2);
                String emailString = email.getText().toString();
                String telefoneString = telefone.getText().toString();
                String senhaString = senha.getText().toString();
                String resultado;

                resultado = crud.insereUsuario(emailString,telefoneString,senhaString);

                Toast.makeText(getApplicationContext(), resultado, Toast.LENGTH_LONG).show();
            }
        });
    }
}