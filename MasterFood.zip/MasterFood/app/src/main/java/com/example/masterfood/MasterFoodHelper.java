package com.example.masterfood;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * Classe responsavel pela construcao do banco
 */
public class MasterFoodHelper extends SQLiteOpenHelper {

    //CREATE TABLE nome_tabela (nome_coluna1 tipo, nome_coluna2,...)


    private static final String SQL_CREATE_USUARIOS =
            "CREATE TABLE " + MasterFoodContract.Usuario.TABLE_NAME + " (" +
                    MasterFoodContract.Usuario.COLUNA_EMAIL + " TEXT PRIMARY KEY," +
                    MasterFoodContract.Usuario.COLUNA_TELEFONE + " TEXT," +
                    MasterFoodContract.Usuario.COLUNA_SENHA  + " TEXT) ";

    private static final String SQL_DELETE_USUARIOS =
            "DROP TABLE IF EXISTS " + MasterFoodContract.Usuario.TABLE_NAME;

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "MasterFood.db";

    public MasterFoodHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    //Metodo chamado ao criar o banco de dados
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_USUARIOS);
    }

    //Metodo chamado ao fazer uma atualizacao no banco de dados
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_USUARIOS);
        onCreate(db);
    }
}
