package com.example.masterfood;


import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Vamos criar a classe DataFragment como subclasse de DialogFragment, que é subclasse de Fragment
 */

public class Fragment{
    private LayoutInflater inflater;
    private ViewGroup container;
    private Bundle savedInstanceState;

    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        this.inflater = inflater;
        this.container = container;
        this.savedInstanceState = savedInstanceState;
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment, container, false);

    }
}
