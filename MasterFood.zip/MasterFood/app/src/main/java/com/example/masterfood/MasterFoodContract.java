package com.example.masterfood;

import android.provider.BaseColumns;

public final class MasterFoodContract {

    private MasterFoodContract() {}

    public static class Usuario implements BaseColumns{
        public static final String TABLE_NAME = "Usuario";
        public static final String COLUNA_EMAIL = "email";
        public static final String COLUNA_TELEFONE = "telefone";
        public static final String COLUNA_SENHA = "senha";
    }
}
