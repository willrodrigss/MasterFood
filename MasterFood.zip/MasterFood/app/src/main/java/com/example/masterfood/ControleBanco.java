package com.example.masterfood;


import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

//Classe que vai fazer as manipulacoes de dados no banco
public class ControleBanco {

    private SQLiteDatabase db;
    private MasterFoodHelper banco;

    public ControleBanco(Context context){
        banco = new MasterFoodHelper(context);
    }

    public String insereUsuario(String email, String telefone, String senha){
        ContentValues valores;
        long resultado;

        //Pega o banco com permissao de escrita
        db = banco.getWritableDatabase();
        //Define os valores para serem escritos na tabela
        valores = new ContentValues();
        valores.put(MasterFoodContract.Usuario.COLUNA_EMAIL,email);
        valores.put(MasterFoodContract.Usuario.COLUNA_TELEFONE, telefone);
        valores.put(MasterFoodContract.Usuario.COLUNA_SENHA, senha);
        //chama a funcao para inserir no banco
        resultado = db.insert(MasterFoodContract.Usuario.TABLE_NAME, null, valores);
        db.close();

        if (resultado ==-1)
            return "Erro ao inserir registro";
        else
            return "Registro inserido com sucesso";
    }

    public Cursor carregaDadosUsuario(){
        Cursor cursor;
        String[] campos =  {MasterFoodContract.Usuario.COLUNA_EMAIL};
        db = banco.getReadableDatabase();
        cursor = db.query(MasterFoodContract.Usuario.TABLE_NAME, campos, null, null, null, null, null, null);

        if(cursor!=null){
            cursor.moveToFirst();
        }
        db.close();
        return cursor;
    }

    //Metodo que informa se um livro foi emprestado para alguem
    /*public String cadastrarEmprestimoLivro(String titulo)
    {

    }*/

}